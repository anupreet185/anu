<?php
$con=mysqli_connect('localhost','root','','anu');
if($con){
    // echo "Connection successfull";
}else{
    die(mysqli_error($con));
}

?>
