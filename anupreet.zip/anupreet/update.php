<?php 
include'connect.php';
$id=$_GET['updateid'];
$sql="select * from crude where id=$id";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($result);
$name=$row['name'];
$email=$row['email'];
$phone=$row['mobile'];
$password=$row['password'];
if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $password=$_POST['password'];

    $sql="update crude set name='$name',email='$email',mobile='$phone',password='$password' where id =$id";
    
    $result=mysqli_query($con,$sql);
    if($result){
        //echo"update successfully";
        header('location:display.php');
    }else{
        die(mysqli_error($con));
    }


}
?>
<html lang="en">
    <head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-5">
        <form method="POST">
            <div class="form-group">
                <label>Name</label>
                <input type="text"class="form-control"placeholder="enter your name"name="name"autocomplete="off"value=<?php echo $name;?>>
</div>
<div class="form-group">
<label>email</label>
<input type="email" class="form-control"placeholder="enter your email" name="email"autocamplete="off" value=<?php echo$email;?>>
</div>
<div class="form-group">
    <label>phone</label>
    <input type="text" class="form-control" placholder="enter your phone number" name="phone" autocomplete="of" value=<?php echo $phone;?>>
</div>
<div class="form-group">
    <label>password</label>
    <input type="text"class="form-control"placeholder="enter your password" name="password" autocomplete="of" value=<?php echo $password; ?>>
</div>
<input type="submit" class="btn btn-primary" name="submit" value="submit">
</form>
</body>
</html>



